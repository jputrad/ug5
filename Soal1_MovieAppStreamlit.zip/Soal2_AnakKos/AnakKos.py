import streamlit as st
import pandas as pd

# --- Title ---
st.title("Perhitungan Pengeluaran Keuangan Anak Kos")


# --- Input Uang Bulanan ---
st.subheader("Uang Bulanan")
uang_bulanan = st.number_input("Masukan uang Bulanan", min_value=0, step=100000)


# --- Input Pengeluaran ---
st.subheader("Pengeluaran Bulanan")
makanan = st.number_input("Makanan", min_value=0, step=10000) # Ada 5
kos = st.number_input("Kos", min_value=0, step=10000) # Kategori
transportasi = st.number_input("Transportasi", min_value=0, step=10000) # Kategori
internet = st.number_input("Internet/Pulsa", min_value=0, step=10000) 
hiburan = st.number_input("Hiburan", min_value=0, step=10000) # Kategori

# --- Tombol Ngitung Pengeluaran ---
if st.button("Hitung Pengeluaran"):

    # --- Ngitung Total Pengeluaran ---
    total_pengeluaran = makanan + kos + transportasi + internet + hiburan

    # --- Ngitung Sisa Uang ---
    sisa_uang = uang_bulanan - total_pengeluaran


    # --- Menampilkan Hasil Perhitungan ---
    st.subheader("Ringkasan Keuangan")
    kolom1, kolom2, kolom3 = st.columns(3)
    with kolom1:
        st.metric(
            # Tampilin uang bulanan di sini
            "Uang Bulanan",
            f"Rp {uang_bulanan:,. 0f}"
        )
    with kolom2:
        st.metric(
            # Tampilin total pengeluaran di sini
            "Total Pengeluaran",
            f"Rp {total_pengeluaran:,. 0f}"
        )
    with kolom3:
        st.metric(
            # Tampilin sisa uang di sini
            "Sisa Uang",
            f"Rp {sisa_uang:,. 0f}"
        )


    # --- Kondisi Keuangan ---
    st.subheader("Kondisi Keuangan")

    # Kondisi 1
    if sisa_uang > 0:
        st.success("Keuangan masih aman, masih ada sisa uang.")
    # Kondisi 2
    elif sisa_uang == 0:
        st.warning("Keuangan Anda habis tepat sesuai pengeluaran.")

    # Kondisi 3
    else:
        st.error("Pengeluaran melebihi uang bulanan.")

    # --- Data Pengeluaran ---
    # Ini gausah diubah! 
    # Udah kubantu bikinin, tinggal dipake aja
    data_pengeluaran = {
        "Kategori": [
            "Makanan",
            "Kos",
            "Transportasi",
            "Internet/Pulsa",
            "Hiburan"
        ],
        "Pengeluaran": [
            makanan,
            kos,
            transportasi,
            internet,
            hiburan
        ]
    }

    df_pengeluaran = pd.DataFrame(data_pengeluaran)

    # --- Pengeluaran Terbesar ---
    pengeluaran_terbesar = df_pengeluaran["Pengeluaran"].max()
    kategori_terbesar = df_pengeluaran.loc[df_pengeluaran["Pengeluaran"].idxmax()]

    st.subheader("Pengeluaran Terbesar")
    st.write(f"Kategori: {kategori_terbesar['Kategori']}")
    st.write(f"Jumlah: Rp {pengeluaran_terbesar:,.0f}")

    # --- Grafik Pengeluaran ---
    st.subheader("Grafik Pengeluaran")
    st.bar_chart(df_pengeluaran.set_index("Kategori")["Pengeluaran"])